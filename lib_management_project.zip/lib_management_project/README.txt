
Program: Library management.
Author: Sheetal Mannan.
Date: January 12,2021.

This C project is on library menu management with various options to Add books, List Books, list by author, List by title, Count books etc..
Program uses structure to store books records. 
Book record includes book title, author name, accession number and flag to know whether the book the issued or not.

The program displays a list of 6 options for the user to choose from.
It uses switch for all cases(options) that user chooses to work on.
Case1 allows the user to add books to the library and case2 displays the user-entered data.
Case3 and 4 allow the user to search information using the author's name or the book's name.
case5 displays the total number of books registered in the library.
Case6 is the exit option which ends the execution of the program.

Important information before executing the code:
The program does not accomodate entries that include spaces in them. Example: "C programming" is not acceptable but "Cprogramming" is accepted.





